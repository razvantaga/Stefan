/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4;

/**
 *
 * @author User
 */
import java.util.*;
import java.util.stream.IntStream;
public class Lab4 {
    public static void main(String[] args) {
        Resident r0 = new Resident("R0");
        Resident r1 = new Resident("R1");
        Resident r2 = new Resident("R2");
        Resident r3 = new Resident("R3");
        
        List<Resident> residentList = new ArrayList<>();
        residentList.add(r0);
        residentList.add(r1);
        residentList.add(r2);
        residentList.add(r3);
        Collections.sort(residentList);
        
        Hospital h0 = new Hospital("H0");
        Hospital h1 = new Hospital("H1");
        Hospital h2 = new Hospital("H2");

        
        Map<Resident, List<Hospital>> resPrefMap = new HashMap<>();
        List<Hospital> prefList = new ArrayList<>();

        prefList.add(h0);
        prefList.add(h1);
        prefList.add(h2);
        
        var r = IntStream.rangeClosed(0, 3)
                .mapToObj(i -> new Resident("R" + i))
                .toArray(Resident[]::new);

        resPrefMap.put(r[0], Arrays.asList(h0, h1, h2));
        resPrefMap.put(r[1], Arrays.asList(h0, h1, h2));
        resPrefMap.put(r[2], Arrays.asList(h0, h1));
        resPrefMap.put(r[3], Arrays.asList(h0, h2));
        System.out.println(resPrefMap);
        
    }
}
